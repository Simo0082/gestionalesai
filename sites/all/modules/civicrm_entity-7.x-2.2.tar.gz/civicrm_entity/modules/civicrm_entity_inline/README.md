# civicrm_entity_inline

This module provides integration of inline entity forms, with the entities exposed by CiviCRM Entity. 
Great for adding/editing/deleting CiviCRM entites using a Entity Reference field
